package CarRental;

public interface BookingSystem {

	public void bookCar();

	public String setUserInfo(String firstName, String lastName, String emailAddress);

	public String setDate(String userStartDateInput, String userEndEDateInput, String emailAddressInput);

	public void viewBooking();

	public int cancelBooking(String emailAddress);

	public long calculateTotalCost(long cost);

	// public void payment(); // not implemented in this project
}
