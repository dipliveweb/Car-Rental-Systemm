package CarRental;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public class BookCar implements BookingSystem {

	private int vechileChoice;
	private int numOfDays;
	private int existingBookingNumner = 0;

	private long totalCost;
	private long diffInMillies;
	private long diff;

	private String continueChoice;
	private String cancelChoice;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String userStartDateInput;
	private String userEndEDateInput;
	private String expectedDatePattern = "MM/dd/yyyy";
	private String bookingStatus = "Done";

	private Date startDate;
	private Date endDate;

	private boolean firstTime = true;
	private boolean continueProgram = true;
	private boolean existingFirstDate = false;
	private boolean duplicate = false;

	private Object existingFirstDateData = null;
	private Object existingLastDateData = null;

	private ArrayList<Object> arrli;
	private ConcurrentHashMap<String, ArrayList> hm = new ConcurrentHashMap<>();
	private Set<String> setOfKeySet = hm.keySet();
	private Scanner ScanObj = new Scanner(System.in);

	// This method will get user info, set start date and end date, calculate
	// price and
	// cancel any existing booking if needed

	public void bookCar() {

		System.out.println("************************* Welcome to Vehicle Rental System *************************\n");

		do {

			try {

				// get customer info
				System.out.println("\nPlease enter your First Name");
				firstName = ScanObj.nextLine();

				System.out.println("\nPlease enter your Last Name");
				lastName = ScanObj.nextLine();

				System.out.println("\nPlease enter your Email");
				emailAddress = ScanObj.nextLine();

				// set customer info
				String email = setUserInfo(firstName, lastName, emailAddress);

				// get customer start and end date
				System.out.println("\nHello " + email + ". Please enter the booking start Date (mm/dd/yyyy)");

				userStartDateInput = ScanObj.nextLine();

				System.out.println("Please enter the booking end Date (mm/dd/yyyy)");

				userEndEDateInput = ScanObj.nextLine();

				// set start and end date
				setDate(userStartDateInput, userEndEDateInput, email);

				// view booking
				viewBooking();

				System.out.println("Do you want to cancel your reservation (y/n)");
				cancelChoice = ScanObj.nextLine();

				if (cancelChoice.equals("y")) {
					cancelBooking(emailAddress);
					viewBooking();

				}

				System.out.println("Do you want to continue (y/n)");
				continueChoice = ScanObj.nextLine();

				if (continueChoice.equals("n")) {
					continueProgram = false;

				}
			} catch (InputMismatchException ex) {
				ex.printStackTrace();
			}

		} while (continueProgram);
	}

	public String setUserInfo(String firstName, String lastName, String emailAddress) {

		Customer cus = new Customer();

		cus.setFistName(firstName);
		cus.setLastName(lastName);
		cus.setEmailAdress(emailAddress);

		System.out.println("\nYour user id is " + emailAddress);

		return cus.getEmailAdress();
	}

	// This method will set start date and end . It also prohibits multiple
	// booking on the same day
	public String setDate(String userStartDateInput, String userEndEDateInput, String emailAddressInput) {

		SimpleDateFormat formatter = new SimpleDateFormat(expectedDatePattern);
		arrli = new ArrayList<Object>();

		try {

			startDate = formatter.parse(userStartDateInput);
			endDate = formatter.parse(userEndEDateInput);

			// Format- "Tue Sep 22 00:00:00 EDT 2009"

			if (!firstTime) {

				for (String email : setOfKeySet) {

					for (Object date : hm.get(email)) {
						if (!existingFirstDate) {
							existingFirstDateData = date;
							existingFirstDate = true;
						} else {
							existingLastDateData = date;
						}
					}
					existingFirstDate = false;

					if (startDate.equals(existingFirstDateData) || startDate.equals(existingLastDateData)
							|| (startDate.after((Date) (existingFirstDateData))
									&& startDate.before((Date) (existingLastDateData)))
							|| (startDate.before((Date) (existingFirstDateData))
									&& endDate.after((Date) (existingFirstDateData)))) {
						System.out.println("This date is already booked. New reservation can n't be made");

						bookingStatus = "Not Possible to Book";
						duplicate = true;
						break;

					}
				}
				if (!duplicate) {
					arrli.add(startDate);
					arrli.add(endDate);
					hm.put(emailAddressInput, arrli);

					diffInMillies = Math.abs(endDate.getTime() - startDate.getTime());
					diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
					long totalRentalCost = calculateTotalCost(diff);
					bookingStatus = "Done";

				}

				duplicate = false;

			} else {
				arrli.add(startDate);
				arrli.add(endDate);
				hm.put(emailAddressInput, arrli);
				firstTime = false;

				diffInMillies = Math.abs(endDate.getTime() - startDate.getTime());
				diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

				long totalRentalCost = calculateTotalCost(diff);

			}

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return bookingStatus;

	}

	public long calculateTotalCost(long day) {

		// here we could have used generic object instead of Sedan
		// object. Since we are only using one type (Sedan) that's why I am
		// using Sedan object
		totalCost = new Sedan().totalRentingCostPerday(day);
		return totalCost;

	}

	public void viewBooking() {

		System.out.println("Full view of the booking System");
		for (String email : setOfKeySet) {

			System.out.println("\nEmail Address: " + email + "\nBooking Dates(to-from) for " + email + ":");

			for (Object date : hm.get(email)) {
				System.out.println("\t\t\t\t" + date);

			}

		}
	}

	public int cancelBooking(String emailAdress) {
		hm.remove(emailAdress);

		for (String email : setOfKeySet) {
			existingBookingNumner++;

		}
		System.out.println("Existing number of user reservation " + existingBookingNumner);
		return existingBookingNumner;
	}

}
