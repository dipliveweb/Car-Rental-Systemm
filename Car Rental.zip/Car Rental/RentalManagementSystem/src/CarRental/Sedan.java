package CarRental;

public class Sedan implements Vehicle {

	private static int initialSedanCount = 1;

	private static int numOfAvailableSedan = 1;

	private static long costPerDay = 100;

	public void engine() {
		System.out.println("V4");
	}

	public void color() {
		System.out.println("Black");
	}

	public void numOfSeats() {
		System.out.println("5");
	}

	public long totalRentingCostPerday(long day) {
		System.out.println("Congratulation!! Your booking is completed.Total Cost of booking sedan for " + day
				+ " day(s) is " + day * costPerDay);

		return day * costPerDay;

	}

}
