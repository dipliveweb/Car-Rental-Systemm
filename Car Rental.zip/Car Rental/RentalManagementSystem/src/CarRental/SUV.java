package CarRental;

//not used this class
public class SUV implements Vehicle {

	private int numOfSUVAvailable = 5;
	private static int costPerDay = 200;

	public void engine() {
		System.out.println("V6");
	}

	public void color() {
		System.out.println("White");
	}

	public void numOfSeats() {
		System.out.println("8");
	}

	public long totalRentingCostPerday(long day) {
		System.out.println("Congratulation!! Your booking is completed.Total Cost of booking sedan for " + day
				+ " day(s) is " + day * costPerDay);

		return day * costPerDay;

	}

}
