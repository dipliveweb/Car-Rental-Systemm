package CarRental;

public interface Vehicle {

	public void engine();

	public void color();

	public void numOfSeats();

	public long totalRentingCostPerday(long day);
}
