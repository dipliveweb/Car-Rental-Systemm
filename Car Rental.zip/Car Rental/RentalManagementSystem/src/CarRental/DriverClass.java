package CarRental;

public class DriverClass {

	public static void main(String[] args) {

		// Get user input and perform actions accordingly
		BookCar dc = new BookCar();
		dc.bookCar();
		System.out.println("Thank you for using our system.Good bye.");

	}

}
