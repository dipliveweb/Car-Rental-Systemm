import static org.junit.Assert.assertEquals;

import org.junit.Test;

import CarRental.BookCar;

public class TestRentalManagementSystem {

	@Test
	public void test() {

		BookCar bc = new BookCar();

		// Expected values
		String expectedEmailAddress = "test@yahoo.com";
		long expectedCostForSedan = 300;
		String expectedBookingStatusWithNoOverlapping = "Done";
		String expectedBookingStatusWithOverlapping = "Not Possible to Book";
		int expectedNumberOfBooking = 1;

		// Actual test

		System.out.println("Test case - 1");
		// check email address
		assertEquals(expectedEmailAddress, bc.setUserInfo("A", "B", "test@yahoo.com"));

		System.out.println("\nTest case - 2");
		// Creating new reservation and test for user test@yahoo.com
		assertEquals(expectedBookingStatusWithNoOverlapping, bc.setDate("11/03/2018", "11/05/2018", "test@yahoo.com"));

		System.out.println("\nTest case - 3");
		// creating duplicate reservation and test for user test@yahoo.com
		assertEquals(expectedBookingStatusWithOverlapping, bc.setDate("11/03/2018", "11/05/2018", "test@yahoo.com"));

		System.out.println("\nTest case - 4");
		// Trying to create a new reservation but in the overlapping timeframe
		// for user test@yahoo.com
		assertEquals(expectedBookingStatusWithOverlapping, bc.setDate("11/04/2018", "11/06/2018", "test@yahoo.com"));

		System.out.println("\nTest case - 5");
		// Trying to create a new reservation but in the overlapping timeframe
		// for user test@yahoo.com
		assertEquals(expectedBookingStatusWithOverlapping, bc.setDate("11/05/2018", "11/07/2018", "test@yahoo.com"));

		System.out.println("\nTest case - 6");
		// Creating a new reservation and test for user test@yahoo.com
		assertEquals(expectedBookingStatusWithNoOverlapping, bc.setDate("11/08/2018", "11/12/2018", "test@yahoo.com"));

		System.out.println("\nTest case - 7");
		// Creating a new reservation and test for a new user
		// testNewUser@yahoo.com
		assertEquals(expectedBookingStatusWithNoOverlapping,
				bc.setDate("11/15/2018", "11/20/2018", "testNewUser@yahoo.com"));

		System.out.println("\nTest case - 8");
		// Trying to create a new reservation but in the overlapping timeframe
		// for user test@yahoo.com. checking after adding few more entries into
		// Hmap+LinkedList
		assertEquals(expectedBookingStatusWithOverlapping, bc.setDate("11/16/2018", "11/17/2018", "test@yahoo.com"));

		System.out.println("\nTest case - 9");
		// Trying to create a new reservation but in the overlapping timeframe
		// for user test@yahoo.com
		assertEquals(expectedBookingStatusWithOverlapping, bc.setDate("11/13/2018", "11/17/2018", "test@yahoo.com"));

		System.out.println("\nTest case -10");
		// check cost calculation
		assertEquals(expectedCostForSedan, bc.calculateTotalCost(3));

		System.out.println("\nTest case -11");
		// Canceling the reservation for user testNewUser@yahoo.com. Please
		// note if we want to cancel reservation for a particular user, all
		// reservation associated with that email id gets deleted. This is the
		// current system behavior. In code, if you hit y to cancel reservation,
		// it tires to figure out if any entry is present for the **last** entered email
		// address. If yes then it deletes that entry.

		assertEquals(expectedNumberOfBooking, bc.cancelBooking("testNewUser@yahoo.com"));
	}

}
